﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercice_12.Interface
{
    internal interface IVolant
    {
        public void Decoller();
        public void Atterir();
    }
}
