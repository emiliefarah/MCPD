﻿

Console.WriteLine("***Ma liste de todo***");
Console.WriteLine("Aujourd'hui je dois faire:");

Console.WriteLine("\t-Apprendre le c#\n\t" +
    "-Apprendre à utiliser Visual Studio\n\t" +
    "-Comprendre l'affichage 'Console'\n\t" +
    "-Créer mon répertoire \"c:\\MesExercice\\\"pour les ranger\n\t" +
    "-Apprécier les fonctionalités du c#");

