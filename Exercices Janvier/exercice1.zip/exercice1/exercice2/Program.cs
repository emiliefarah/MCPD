﻿
Console.WriteLine("Veuillez saisir votre prénom");
string prenom = Console.ReadLine();
Console.WriteLine(" Bonjour " + prenom);