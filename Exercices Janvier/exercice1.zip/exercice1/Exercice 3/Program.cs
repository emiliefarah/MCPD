﻿
Console.WriteLine("Veuillez saisir votre nom");
string nom = Console.ReadLine();

Console.WriteLine("Veuillez saisir votre prénom");
string prenom = Console.ReadLine();

Console.WriteLine(" Bonjour " + nom + " " + prenom);
