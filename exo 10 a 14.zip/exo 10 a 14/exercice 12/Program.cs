﻿Console.WriteLine("Veuillez entrer un nombre");
int nb1 = int.Parse(Console.ReadLine());
for (int i = 1; i < 11; i++)
{
    Console.WriteLine(i * nb1);
}
Console.WriteLine();