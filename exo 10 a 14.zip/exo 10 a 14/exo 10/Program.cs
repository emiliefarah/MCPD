﻿Console.WriteLine();
for (int i = 1; i <= 30; i++)
{
    if (i % 3 == 0 && i % 5 == 0)
    {
        Console.WriteLine("FizzBuzz");
        continue;

    }
    if (i % 3 == 0)
    {
        Console.WriteLine("Fizz");
        continue;

    }
    if (i % 5 == 0)
    {
        Console.WriteLine("Buzz");
        continue;
    }


    Console.WriteLine(i);

}
